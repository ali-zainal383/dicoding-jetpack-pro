package com.bidin.movie.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.bidin.movie.R
import com.bidin.movie.data.DataEntity
import com.bidin.movie.databinding.ActivityDetailBinding
import com.bidin.movie.utils.TypeHelper.TYPE_MOVIE
import com.bidin.movie.utils.TypeHelper.TYPE_TV
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DATA = "extra_data"
        const val EXTRA_TYPE = "extra_type"
    }

    private lateinit var detailBinding: ActivityDetailBinding
    private lateinit var result : DataEntity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailBinding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(detailBinding.root)

        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailViewModel::class.java]

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val id = intent.getStringExtra(EXTRA_DATA)
        val type = intent.getStringExtra(EXTRA_TYPE)
        when {
            type.equals(TYPE_MOVIE) -> {
                setToolbarTitle(resources.getString(R.string.detail_movie))
                id?.let {
                    viewModel.setSelectedMovie(it)
                }
                result = viewModel.getDetailMovie()
            }
            type.equals(TYPE_TV) -> {
                setToolbarTitle(resources.getString(R.string.detail_tv_show))
                id?.let {
                    viewModel.setSelectedTvShow(it)
                }
                result = viewModel.getDetailTvShow()
            }
        }
        detailBinding.tvTitleDetail.text = result.title
        detailBinding.tvReleaseDetail.text = result.release
        detailBinding.tvDescriptionDetail.text = result.overview
        Glide.with(this)
            .load(result.backDropPath)
            .apply(RequestOptions.placeholderOf(R.drawable.ic_loading)
                .error(R.drawable.ic_error))
            .into(detailBinding.imgBackdrop)
    }

    private fun setToolbarTitle(title: String) {
        supportActionBar?.title = title
    }
}