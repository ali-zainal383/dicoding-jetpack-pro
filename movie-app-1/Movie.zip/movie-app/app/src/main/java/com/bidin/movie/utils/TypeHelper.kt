package com.bidin.movie.utils

object TypeHelper  {
    const val TYPE_MOVIE = "TYPE_MOVIE"
    const val TYPE_TV = "TYPE_TV"
}